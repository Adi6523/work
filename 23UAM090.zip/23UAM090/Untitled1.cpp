#include<iostream>
 
using namespace std;

int main(){


int num1,num2,sum;

cout<<"enter the 1st number:";
cin>>num1;
cout<<"enter the 2st number:";
cin>>num2;
sum=num1+num2;
cout<<"the sum is:"<<sum<<endl;
return 0;


}
